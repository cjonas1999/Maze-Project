MazeReader reads a text file containing the maze as input with the following format:

WALL: #
OPEN SPACE: .
START: o
FINISH: *

Every row of the maze should be of uniform length.